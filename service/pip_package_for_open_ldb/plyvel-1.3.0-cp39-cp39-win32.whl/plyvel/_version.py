"""
Plyvel version module.
"""

# Note: don't add any non-trivial logic here; this file is also loaded
# from setup.py file when the module has not yet been compiled!

__version__ = '1.3.0'
